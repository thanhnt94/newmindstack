# Tệp: web/mindstack_app/db_instance.py
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()
