# File: newmindstack/mindstack_app/modules/content_management/courses/__init__.py
# Phiên bản: 2.0
# Mục đích: Định nghĩa Blueprint cho module con quản lý Khóa học.
#           File này không cần import Blueprint nữa vì nó được đăng ký ở cấp trên.

# File này không cần chứa bất kỳ import Blueprint nào.
# Blueprint 'courses_bp' đã được định nghĩa và import trong:
# newmindstack/mindstack_app/modules/content_management/courses/routes.py
# và được đăng ký trong:
# newmindstack/mindstack_app/modules/content_management/routes.py
